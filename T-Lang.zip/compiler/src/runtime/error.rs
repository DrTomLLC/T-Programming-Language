// compiler/src/runtime/error.rs
//! Definition of runtime errors for the T language evaluator.
//! All errors are handled explicitly; no panics.

use std::fmt;

/// Errors that can occur at runtime or during evaluation.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum RuntimeError {
    /// Lexing error, wraps the lexer's error message.
    LexError(String),
    /// Parsing error, wraps the parser's error message.
    ParseError(String),
    /// Attempted to reference an undefined variable name.
    UndefinedVariable(String),
    /// Division by zero error.
    DivisionByZero,
    /// Type mismatch or invalid operation.
    TypeError(String),
    /// Wrong number of arguments in a function call.
    WrongArity(String, usize, usize),
}

impl fmt::Display for RuntimeError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            RuntimeError::LexError(msg) => write!(f, "Lex error: {}", msg),
            RuntimeError::ParseError(msg) => write!(f, "Parse error: {}", msg),
            RuntimeError::UndefinedVariable(name) => write!(f, "Undefined variable: {}", name),
            RuntimeError::DivisionByZero => write!(f, "Division by zero"),
            RuntimeError::TypeError(msg) => write!(f, "Type error: {}", msg),
            RuntimeError::WrongArity(name, expected, given) => {
                write!(f, "Wrong arity: {} expected {}, got {}", name, expected, given)
            }
        }
    }
}

impl std::error::Error for RuntimeError {}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn display_lex_error() {
        let e = RuntimeError::LexError("unexpected token".into());
        assert_eq!(format!("{}", e), "Lex error: unexpected token");
    }

    #[test]
    fn display_parse_error() {
        let e = RuntimeError::ParseError("mismatched parentheses".into());
        assert_eq!(format!("{}", e), "Parse error: mismatched parentheses");
    }

    #[test]
    fn display_undefined_variable() {
        let e = RuntimeError::UndefinedVariable("x".into());
        assert_eq!(format!("{}", e), "Undefined variable: x");
    }

    #[test]
    fn display_division_by_zero() {
        let e = RuntimeError::DivisionByZero;
        assert_eq!(format!("{}", e), "Division by zero");
    }

    #[test]
    fn display_type_error() {
        let e = RuntimeError::TypeError("cannot add number and string".into());
        assert_eq!(format!("{}", e), "Type error: cannot add number and string");
    }

    #[test]
    fn display_wrong_arity() {
        let e = RuntimeError::WrongArity("f".into(), 2, 3);
        assert_eq!(format!("{}", e), "Wrong arity: f expected 2, got 3");
    }
}
