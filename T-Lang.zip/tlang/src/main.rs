// tlang/src/main.rs

use std::io::{self, Write};

// Import your compiler runtime modules:
use compiler::runtime::error::RuntimeError;
use compiler::runtime::env::Environment;
use compiler::runtime::value::Value;
use compiler::runtime::eval::Evaluator;
use shared::tokenizer::tokenize;
use compiler::parser::Parser;

fn main() {
    let mut evaluator = Evaluator::new();
    println!("T-Lang REPL — Type 'exit;' to quit.");

    let stdin = io::stdin();
    loop {
        print!("> ");
        io::stdout().flush().unwrap();

        let mut input = String::new();
        if stdin.read_line(&mut input).is_err() {
            break;
        }
        let trimmed = input.trim();
        if trimmed == "exit;" {
            break;
        }
        if trimmed.is_empty() {
            continue;
        }

        // 1) Lex
        match tokenize(trimmed) {
            Ok(tokens) => {
                // 2) Parse
                let mut parser = Parser::new(tokens);
                match parser.parse_statement() {
                    Ok(stmt) => {
                        // 3) Evaluate
                        match evaluator.eval_stmt(stmt) {
                            Ok(val) => println!("= {}", val),
                            Err(err) => eprintln!("Runtime error: {}", err),
                        }
                    }
                    Err(parse_err) => eprintln!("Parse error: {}", parse_err),
                }
            }
            Err(lex_err) => eprintln!("Lex error: {}", lex_err),
        }
    }
}
