use shared::ast::Stmt;
use crate::parser::expr::Parser;
use crate::parser::error::ParseError;

impl Parser {
    /// Parse a top‐level statement (let, if, while, or expr‐stmt).
    pub fn parse_statement(&mut self) -> Result<Stmt, ParseError> {
        if self.current_is("let") {
            self.advance();
            let name = self.expect_identifier()?;
            self.expect("=")?;
            let value = self.parse_expression()?;
            self.expect(";")?;
            Ok(Stmt::Let(name, value))
        } else if self.current_is("if") {
            self.advance();
            self.expect("(")?;
            let cond = self.parse_expression()?;
            self.expect(")")?;
            self.expect("{")?;
            let then_branch = self.parse_block()?;
            let else_branch = if self.current_is("else") {
                self.advance();
                self.expect("{")?;
                self.parse_block()?
            } else {
                Vec::new()
            };
            Ok(Stmt::If { cond, then_branch, else_branch })
        } else if self.current_is("while") {
            self.advance();
            self.expect("(")?;
            let cond = self.parse_expression()?;
            self.expect(")")?;
            self.expect("{")?;
            let body = self.parse_block()?;
            Ok(Stmt::While { cond, body })
        } else {
            // expression‐statement
            let expr = self.parse_expression()?;
            self.expect(";")?;
            Ok(Stmt::Expr(expr))
        }
    }

    fn parse_block(&mut self) -> Result<Vec<Stmt>, ParseError> {
        let mut stmts = Vec::new();
        while !self.current_is("}") {
            stmts.push(self.parse_statement()?);
        }
        self.expect("}")?;
        Ok(stmts)
    }

    fn expect_identifier(&mut self) -> Result<String, ParseError> {
        if let Some(tok) = self.current() {
            if tok.token_type.is_identifier() {
                let name = tok.lexeme.clone();
                self.advance();
                return Ok(name);
            }
        }
        Err(ParseError::UnexpectedToken(
            self.current().map_or("<EOF>".into(), |t| t.lexeme.clone())
        ))
    }
}
