// compiler/src/parser/error.rs

use std::fmt;
use shared::tokenizer::LexError;

/// Errors that can occur during parsing.
#[derive(Debug)]
pub enum ParseError {
    UnexpectedEOF,
    UnexpectedToken(String),
    ExpectedToken(String),
    LexError(LexError),
    InvalidNumber(String),
}

impl fmt::Display for ParseError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            ParseError::UnexpectedEOF => write!(f, "Unexpected end of input"),
            ParseError::UnexpectedToken(t) => write!(f, "Unexpected token: {}", t),
            ParseError::ExpectedToken(t) => write!(f, "Expected token: {}", t),
            ParseError::LexError(e) => write!(f, "Lex error: {}", e),
            &ParseError::InvalidNumber(_) => todo!(),
        }
    }
}

impl std::error::Error for ParseError {}

impl From<LexError> for ParseError {
    fn from(err: LexError) -> Self {
        ParseError::LexError(err)
    }
}
