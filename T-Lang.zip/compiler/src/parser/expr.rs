use shared::tokenizer::{Token, tokenize};
use shared::ast::{Expr, UnaryOp, BinaryOp};
use crate::parser::error::ParseError;

/// A simple recursive‐descent parser over a token stream.
pub struct Parser {
    tokens: Vec<Token>,
    pos: usize,
}

impl Parser {
    /// Tokenize `source` and build a new Parser.
    pub fn new(source: &str) -> Self {
        Parser {
            tokens: tokenize(source),
            pos: 0,
        }
    }

    /// Peek at the current token.
    pub fn current(&self) -> Option<&Token> {
        self.tokens.get(self.pos)
    }

    /// Advance one token.
    pub fn advance(&mut self) {
        if self.pos < self.tokens.len() {
            self.pos += 1;
        }
    }

    /// True if current token lexeme == `s`.
    pub(crate) fn current_is(&self, s: &str) -> bool {
        self.current().map_or(false, |t| t.lexeme == s)
    }

    /// Consume `s` or error.
    pub(crate) fn expect(&mut self, s: &str) -> Result<(), ParseError> {
        if self.current_is(s) {
            self.advance();
            Ok(())
        } else {
            Err(ParseError::ExpectedToken(s.to_string()))
        }
    }

    /// Entry point: parse a full expression.
    pub fn parse_expression(&mut self) -> Result<Expr, ParseError> {
        self.parse_logic_or()
    }

    fn parse_logic_or(&mut self) -> Result<Expr, ParseError> {
        let mut expr = self.parse_logic_and()?;
        while self.current_is("or") {
            self.advance();
            let rhs = self.parse_logic_and()?;
            expr = Expr::Binary {
                left: Box::new(expr),
                op: BinaryOp::Or,
                right: Box::new(rhs),
            };
        }
        Ok(expr)
    }

    fn parse_logic_and(&mut self) -> Result<Expr, ParseError> {
        let mut expr = self.parse_equality()?;
        while self.current_is("and") {
            self.advance();
            let rhs = self.parse_equality()?;
            expr = Expr::Binary {
                left: Box::new(expr),
                op: BinaryOp::And,
                right: Box::new(rhs),
            };
        }
        Ok(expr)
    }

    fn parse_equality(&mut self) -> Result<Expr, ParseError> {
        let mut expr = self.parse_comparison()?;
        loop {
            let op = match self.current().map(|t| t.lexeme.as_str()) {
                Some("==") => BinaryOp::EqualEqual,
                Some("!=") => BinaryOp::NotEqual,
                _ => break,
            };
            self.advance();
            let rhs = self.parse_comparison()?;
            expr = Expr::Binary { left: Box::new(expr), op, right: Box::new(rhs) };
        }
        Ok(expr)
    }

    fn parse_comparison(&mut self) -> Result<Expr, ParseError> {
        let mut expr = self.parse_term()?;
        loop {
            let op = match self.current().map(|t| t.lexeme.as_str()) {
                Some("<")  => BinaryOp::Less,
                Some("<=") => BinaryOp::LessEqual,
                Some(">")  => BinaryOp::Greater,
                Some(">=") => BinaryOp::GreaterEqual,
                _ => break,
            };
            self.advance();
            let rhs = self.parse_term()?;
            expr = Expr::Binary { left: Box::new(expr), op, right: Box::new(rhs) };
        }
        Ok(expr)
    }

    fn parse_term(&mut self) -> Result<Expr, ParseError> {
        let mut expr = self.parse_factor()?;
        loop {
            let op = match self.current().map(|t| t.lexeme.as_str()) {
                Some("+") => BinaryOp::Add,
                Some("-") => BinaryOp::Sub,
                _ => break,
            };
            self.advance();
            let rhs = self.parse_factor()?;
            expr = Expr::Binary { left: Box::new(expr), op, right: Box::new(rhs) };
        }
        Ok(expr)
    }

    fn parse_factor(&mut self) -> Result<Expr, ParseError> {
        let mut expr = self.parse_unary()?;
        loop {
            let op = match self.current().map(|t| t.lexeme.as_str()) {
                Some("*") => BinaryOp::Mul,
                Some("/") => BinaryOp::Div,
                _ => break,
            };
            self.advance();
            let rhs = self.parse_unary()?;
            expr = Expr::Binary { left: Box::new(expr), op, right: Box::new(rhs) };
        }
        Ok(expr)
    }

    fn parse_unary(&mut self) -> Result<Expr, ParseError> {
        if let Some(tok) = self.current() {
            match tok.lexeme.as_str() {
                "!" => {
                    self.advance();
                    let inner = self.parse_unary()?;
                    return Ok(Expr::Unary { op: UnaryOp::Not, expr: Box::new(inner) });
                }
                "-" => {
                    self.advance();
                    let inner = self.parse_unary()?;
                    return Ok(Expr::Unary { op: UnaryOp::Negate, expr: Box::new(inner) });
                }
                "if" => {
                    self.advance();
                    self.expect("(")?;
                    let condition = self.parse_expression()?;
                    self.expect(")")?;
                    let then_branch = Box::new(self.parse_expression()?);
                    self.expect("else")?;
                    let else_branch = Box::new(self.parse_expression()?);
                    return Ok(Expr::If { condition: Box::new(condition), then_branch, else_branch });
                }
                _ => {}
            }
        }
        self.parse_primary()
    }

    fn parse_primary(&mut self) -> Result<Expr, ParseError> {
        if let Some(tok) = self.current() {
            let lex = tok.lexeme.as_str();
            if lex == "(" {
                self.advance();
                let e = self.parse_expression()?;
                self.expect(")")?;
                return Ok(Expr::Grouping(Box::new(e)));
            }
            if lex == "[" {
                self.advance();
                let mut elems = Vec::new();
                if !self.current_is("]") {
                    loop {
                        elems.push(self.parse_expression()?);
                        if self.current_is(",") { self.advance(); continue; }
                        break;
                    }
                }
                self.expect("]")?;
                return Ok(Expr::ListLiteral(elems));
            }
            if let Ok(n) = lex.parse::<f64>() {
                self.advance();
                return Ok(Expr::LiteralNumber(n));
            }
            if lex == "true" || lex == "false" {
                let b = lex == "true";
                self.advance();
                return Ok(Expr::LiteralBool(b));
            }
            if lex.starts_with('"') && lex.ends_with('"') && lex.len() >= 2 {
                let s = lex[1..lex.len()-1].to_string();
                self.advance();
                return Ok(Expr::LiteralString(s));
            }
            if is_identifier(lex) {
                let name = lex.to_string();
                self.advance();
                if self.current_is("(") {
                    self.advance();
                    let mut args = Vec::new();
                    if !self.current_is(")") {
                        loop {
                            args.push(self.parse_expression()?);
                            if self.current_is(",") { self.advance(); continue; }
                            break;
                        }
                    }
                    self.expect(")")?;
                    return Ok(Expr::Call(name, args));
                }
                return Ok(Expr::Variable(name));
            }
        }
        Err(ParseError::UnexpectedToken(
            self.current().map_or("<EOF>".into(), |t| t.lexeme.clone())
        ))
    }
}

fn is_identifier(s: &str) -> bool {
    let mut chars = s.chars();
    match chars.next() {
        Some(c) if c.is_alphabetic() || c == '_' => (),
        _ => return false,
    }
    chars.all(|c| c.is_alphanumeric() || c == '_')
}
