// compiler/src/lib.rs
pub mod parser;
pub mod runtime;