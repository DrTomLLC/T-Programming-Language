//! Core evaluator for T‑Lang AST.

use crate::runtime::env::Environment;
use crate::runtime::error::RuntimeError;
use crate::runtime::value::Value;
use shared::ast::{Expr, Stmt, BinaryOp, UnaryOp};

/// Carries a mutable reference to the current environment.
pub struct Evaluator<'a> {
    env: &'a mut Environment,
}

impl<'a> Evaluator<'a> {
    /// Create a new evaluator around the given environment.
    pub fn new(env: &'a mut Environment) -> Self {
        Evaluator { env }
    }

    /// Evaluate a top‐level statement.
    pub fn eval_stmt(&mut self, stmt: Stmt) -> Result<Value, RuntimeError> {
        match stmt {
            Stmt::Expr(expr) => self.eval_expr(expr),

            Stmt::Let(name, expr) => {
                let val = self.eval_expr(expr)?;
                // define at current scope
                self.env.define(name.clone(), val.clone());
                Ok(val)
            }

            Stmt::Assign(name, expr) => {
                let val = self.eval_expr(expr)?;
                self.env.assign(name.clone(), val.clone())?;
                Ok(val)
            }

            Stmt::If { cond, then_branch, else_branch } => {
                if self.eval_expr(cond)?.is_truthy() {
                    self.eval_block(then_branch)
                } else {
                    self.eval_block(else_branch)
                }
            }

            Stmt::While { cond, body } => {
                while self.eval_expr(cond.clone())?.is_truthy() {
                    self.eval_block(body.clone())?;
                }
                Ok(Value::Unit)
            }

            Stmt::Block(stmts) => self.eval_block(stmts),

            Stmt::Function(name, params, body) => {
                // store the function (params+body) as a first‐class value
                let f = Value::Function(params.clone(), body.clone());
                self.env.define(name.clone(), f.clone());
                Ok(f)
            }
        }
    }

    /// Helper for evaluating a sequence of statements in order.
    fn eval_block(&mut self, stmts: Vec<Stmt>) -> Result<Value, RuntimeError> {
        let mut last = Value::Unit;
        for s in stmts {
            last = self.eval_stmt(s)?;
        }
        Ok(last)
    }

    /// Evaluate an expression.
    pub fn eval_expr(&mut self, expr: Expr) -> Result<Value, RuntimeError> {
        match expr {
            Expr::LiteralNumber(n)   => Ok(Value::Number(n)),
            Expr::LiteralBool(b)     => Ok(Value::Bool(b)),
            Expr::LiteralString(s)   => Ok(Value::Str(s)),
            Expr::Variable(name)     => self.env.get(&name),
            Expr::Grouping(inner)    => self.eval_expr(*inner),

            Expr::Unary { op, expr } => {
                let v = self.eval_expr(*expr)?;
                match op {
                    UnaryOp::Negate => match v {
                        Value::Number(n) => Ok(Value::Number(-n)),
                        _ => Err(RuntimeError::TypeError("Unary '-' on non‐number".into())),
                    },
                    UnaryOp::Not => Ok(Value::Bool(!v.is_truthy())),
                }
            }

            Expr::Binary { left, op, right } => {
                // short‐circuit for `and`/`or`
                if op == BinaryOp::And {
                    let l = self.eval_expr(*left)?;
                    if !l.is_truthy() {
                        return Ok(Value::Bool(false));
                    }
                    let r = self.eval_expr(*right)?;
                    return Ok(Value::Bool(r.is_truthy()));
                }
                if op == BinaryOp::Or {
                    let l = self.eval_expr(*left)?;
                    if l.is_truthy() {
                        return Ok(Value::Bool(true));
                    }
                    let r = self.eval_expr(*right)?;
                    return Ok(Value::Bool(r.is_truthy()));
                }

                // otherwise evaluate both sides
                let l = self.eval_expr(*left)?;
                let r = self.eval_expr(*right)?;
                match (op, l, r) {
                    (BinaryOp::Add, Value::Number(a), Value::Number(b))        => Ok(Value::Number(a + b)),
                    (BinaryOp::Sub, Value::Number(a), Value::Number(b))        => Ok(Value::Number(a - b)),
                    (BinaryOp::Mul, Value::Number(a), Value::Number(b))        => Ok(Value::Number(a * b)),
                    (BinaryOp::Div, Value::Number(_), Value::Number(0.0))      => Err(RuntimeError::DivisionByZero),
                    (BinaryOp::Div, Value::Number(a), Value::Number(b))        => Ok(Value::Number(a / b)),
                    (BinaryOp::Less, Value::Number(a), Value::Number(b))       => Ok(Value::Bool(a < b)),
                    (BinaryOp::LessEqual, Value::Number(a), Value::Number(b))  => Ok(Value::Bool(a <= b)),
                    (BinaryOp::Greater, Value::Number(a), Value::Number(b))    => Ok(Value::Bool(a > b)),
                    (BinaryOp::GreaterEqual, Value::Number(a), Value::Number(b)) => Ok(Value::Bool(a >= b)),
                    (BinaryOp::EqualEqual, vl, vr)                             => Ok(Value::Bool(vl == vr)),
                    (BinaryOp::NotEqual, vl, vr)                               => Ok(Value::Bool(vl != vr)),
                    _ => Err(RuntimeError::TypeError("Invalid operands for binary operator".into())),
                }
            }

            Expr::Call(name, args) => {
                let mut arg_vals = Vec::with_capacity(args.len());
                for a in args {
                    arg_vals.push(self.eval_expr(a)?);
                }
                self.call_function(name, arg_vals)
            }

            Expr::ListLiteral(elements) => {
                let mut vs = Vec::with_capacity(elements.len());
                for e in elements {
                    vs.push(self.eval_expr(e)?);
                }
                Ok(Value::List(vs))
            }

            Expr::If { condition, then_branch, else_branch } => {
                if self.eval_expr(*condition)?.is_truthy() {
                    self.eval_expr(*then_branch)
                } else {
                    self.eval_expr(*else_branch)
                }
            }

            Expr::Block(stmts) => {
                // new nested scope for a block expression
                let mut child_env = Environment::with_parent(self.env);
                let mut child_eval = Evaluator::new(&mut child_env);
                child_eval.eval_block(stmts)
            }
        }
    }

    /// Invoke a user‐defined function by name.
    fn call_function(&mut self, name: String, args: Vec<Value>) -> Result<Value, RuntimeError> {
        let f = self.env.get(&name)?;
        if let Value::Function(params, body) = f {
            if params.len() != args.len() {
                return Err(RuntimeError::WrongArity(name, params.len(), args.len()));
            }
            // new scope for parameters
            let mut child_env = Environment::with_parent(self.env);
            for (p, v) in params.into_iter().zip(args.into_iter()) {
                child_env.define(p, v);
            }
            let mut child_eval = Evaluator::new(&mut child_env);
            child_eval.eval_block(body)
        } else {
            Err(RuntimeError::TypeError(format!("{} is not a function", name)))
        }
    }
}
