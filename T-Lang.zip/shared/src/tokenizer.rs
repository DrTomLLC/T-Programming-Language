// shared/src/tokenizer.rs
//! A safety‑critical, mission‑critical lexer.
//! Never panics; always returns a `Result`.

use std::fmt;

/// An error produced during lexing, with precise location.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct LexError {
    pub line: usize,
    pub col: usize,
    pub message: &'static str,
}

impl fmt::Display for LexError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "LexError at {}:{} — {}", self.line, self.col, self.message)
    }
}

impl std::error::Error for LexError {}

/// A single lexical token.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Token {
    /// The exact lexeme text.
    pub lexeme: String,
    /// Line where this token was found (1‑based).
    pub line: usize,
    /// Column where this token starts (1‑based).
    pub col: usize,
}

/// Splits the input on ASCII whitespace into simple tokens.
/// Returns `Err(LexError)` on empty input.
pub fn tokenize(src: &str) -> Result<Vec<Token>, LexError> {
    if src.is_empty() {
        return Err(LexError {
            line: 1,
            col: 1,
            message: "empty input",
        });
    }

    let mut tokens = Vec::new();
    let mut line = 1;
    let mut col = 1;
    let mut chars = src.char_indices().peekable();

    while let Some((idx, ch)) = chars.next() {
        if ch == '\n' {
            line += 1;
            col = 1;
            continue;
        }
        if ch.is_ascii_whitespace() {
            col += 1;
            continue;
        }

        // start of a token
        let start_col = col;
        let start = idx;
        let mut end = idx;

        // consume until next whitespace or newline
        while let Some(&(_, next_ch)) = chars.peek() {
            if next_ch.is_ascii_whitespace() {
                break;
            }
            let (next_idx, _) = chars.next().unwrap();
            end = next_idx;
            col += 1;
        }

        let lexeme = src[start..=end].to_string();
        tokens.push(Token {
            lexeme,
            line,
            col: start_col,
        });
        col += 1;
    }

    Ok(tokens)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn empty_input_is_error() {
        let err = tokenize("").unwrap_err();
        assert_eq!(
            err,
            LexError {
                line: 1,
                col: 1,
                message: "empty input"
            }
        );
    }

    #[test]
    fn single_word_tokenizes() {
        let toks = tokenize("foo").expect("should lex foo");
        assert_eq!(toks.len(), 1);
        let t = &toks[0];
        assert_eq!(t.lexeme, "foo");
        assert_eq!(t.line, 1);
        assert_eq!(t.col, 1);
    }

    #[test]
    fn multiple_words_and_lines() {
        let input = "let x = 5;\nprint x;";
        let toks = tokenize(input).expect("should lex multiple");
        let lexemes: Vec<_> = toks.iter().map(|t| t.lexeme.as_str()).collect();
        assert_eq!(
            lexemes,
            ["let", "x", "=", "5;", "print", "x;"]
        );
        // ensure line/col tracking on second line
        let second_line_tokens: Vec<_> = toks.iter().filter(|t| t.line == 2).collect();
        assert_eq!(second_line_tokens.len(), 2);
    }
}
