// compiler/src/runtime/value.rs
//! Runtime Value definitions for T‑Lang evaluator.
//! Uses shared AST for function bodies.

use std::fmt;
use shared::ast::Stmt;

use crate::runtime::error::RuntimeError;

/// A value in T‑Lang at runtime.
#[derive(Debug, Clone, PartialEq)]
pub enum Value {
    Unit,
    Number(f64),
    Bool(bool),
    Str(String),
    List(Vec<Value>),
    /// Function parameters and body AST.
    Function(Vec<String>, Vec<Stmt>),
}

impl fmt::Display for Value {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Value::Unit => write!(f, "()"),
            Value::Number(n) => write!(f, "{}", n),
            Value::Bool(b) => write!(f, "{}", b),
            Value::Str(s) => write!(f, "\"{}\"", s),
            Value::List(items) => {
                write!(f, "[")?;
                let mut first = true;
                for v in items {
                    if !first { write!(f, ", ")?; }
                    write!(f, "{}", v)?;
                    first = false;
                }
                write!(f, "]")
            }
            Value::Function(params, _) => write!(f, "<fn({})>", params.join(", ")),
        }
    }
}

impl Value {
    pub fn type_name(&self) -> &'static str {
        match self {
            Value::Unit => "Unit",
            Value::Number(_) => "Number",
            Value::Bool(_) => "Bool",
            Value::Str(_) => "Str",
            Value::List(_) => "List",
            Value::Function(_, _) => "Function",
        }
    }

    pub fn is_truthy(&self) -> bool {
        match self {
            Value::Bool(b) => *b,
            Value::Number(n) => *n != 0.0,
            Value::Str(s) => !s.is_empty(),
            Value::List(v) => !v.is_empty(),
            Value::Unit => false,
            Value::Function(_, _) => true,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn function_display() {
        let val = Value::Function(vec!["x".into(), "y".into()], vec![]);
        assert_eq!(format!("{}", val), "<fn(x, y)>");
    }
}
