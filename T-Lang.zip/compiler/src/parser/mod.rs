// parser/mod.rs
pub mod error;
pub mod expr;
pub mod stmt;
mod tests;

// Re‑export the main Parser type at the top level
pub use expr::Parser;
